class TouchBridgePanel extends HTMLElement {
    connectedCallback() {
        // 🛑 The Zombie Guard: Prevents MSFS from spawning duplicate background connections
        if (this.isInitialized) return;
        this.isInitialized = true;

        setTimeout(() => {
            this.statusDiv = document.getElementById("connection-status");
            this.telemetryDiv = document.getElementById("telemetry-output");
            
            // --- PERMANENT PIN STORAGE ---
            let storedPin = null;

            try { 
                storedPin = GetStoredData("efb_pairing_pin"); 
            } catch(e) { 
                console.warn("MSFS DataStore unavailable, using localStorage fallback."); 
            }

            if (!storedPin || storedPin === "") {
                storedPin = localStorage.getItem("efb_pairing_pin");
            }

            if (!storedPin || storedPin === "") {
                storedPin = Math.random().toString(36).substring(2, 8).toUpperCase();
                try { SetStoredData("efb_pairing_pin", storedPin); } catch(e) {}
                localStorage.setItem("efb_pairing_pin", storedPin);
            }

            this.pairingPin = storedPin;
            this.customVarsManifest = [];
            this.previousPayload = {};
            this.tickCount = 0; 

            this.initTwoWaySocket();
        }, 1500);
    }

    initTwoWaySocket() {
        if(this.statusDiv) this.statusDiv.innerHTML = `<strong style='color: orange;'>CONNECTING...</strong>`;
        
        try {
            window.bridgeSocket = new WebSocket("wss://msfs-relay.onrender.com");

            window.bridgeSocket.addEventListener("open", () => {
                window.bridgeSocket.send(JSON.stringify({ type: "join", pin: this.pairingPin }));
                if(this.statusDiv) this.statusDiv.innerHTML = `<strong style='color: limegreen;'>PAIRED: ${this.pairingPin}</strong>`;
                
                this.previousPayload = {}; 
                this.startTelemetryLoop();
            });

            window.bridgeSocket.addEventListener("message", (event) => {
                try {
                    let data = JSON.parse(event.data);
                    
                    const validActionTypes = ["SD_COMMAND", "SET_CUSTOM_VARS", "REQUEST_STATE"];
                    if (!data || !data.type || !validActionTypes.includes(data.type)) return;

                    if(this.statusDiv) {
                        this.statusDiv.innerHTML = `<strong style='color: cyan;'>RCV: ${data.command || data.type}</strong>`;
                        setTimeout(() => {
                            if(this.statusDiv) this.statusDiv.innerHTML = `<strong style='color: limegreen;'>PAIRED: ${this.pairingPin}</strong>`;
                        }, 1000);
                    }

                    if (data.type === "SET_CUSTOM_VARS") {
                        this.customVarsManifest = data.vars || [];
                        this.previousPayload = {}; 
                    }

                    if (data.type === "REQUEST_STATE") {
                        this.previousPayload = {}; 
                    }

                    // ==========================================
                    // --- THE HYBRID MACRO ENGINE ---
                    // ==========================================
                    if (data.type === "SD_COMMAND" && data.command) {
                        let rawCmd = String(data.command).trim();
                        
                        if (rawCmd.includes("(>")) {
                            let parts = rawCmd.split(")"); 
                            let cleanRpnString = "";
                            
                            parts.forEach(part => {
                                if (!part.trim()) return;
                                
                                let match = part.match(/(?:(-?\d+(?:\.\d+)?)\s*)?\(\>(L|K|A|B|H|O):([^,)]+)/i);
                                
                                if (match) {
                                    let val = match[1] !== undefined ? parseFloat(match[1]) : 1;
                                    let type = match[2].toUpperCase();
                                    let name = match[3].trim();
                                    
                                    if (type === "A") {
                                        console.warn(`[BLOCKED] Read-only A: variable ignored.`);
                                    } 
                                    else if (type === "B") {
                                        // 🛑 CRITICAL INTERCEPT: The calculator ignores B: events. 
                                        // We MUST route them natively through the modern SimVar API!
                                        SimVar.SetSimVarValue(`B:${name}`, "number", val);
                                        console.log(`[B-EVENT FIRE] B:${name} = ${val}`);
                                    } 
                                    else {
                                        // Standard L: and K: events get bundled for the calculator
                                        cleanRpnString += part + ") ";
                                    }
                                } else {
                                    cleanRpnString += part + ") ";
                                }
                            });

                            if (cleanRpnString.trim() !== "") {
                                Coherent.call("EXECUTE_CALCULATOR_CODE", cleanRpnString.trim());
                                console.log(`[MACRO FIRE] ${cleanRpnString.trim()}`);
                            }
                        } 
                        else if (rawCmd.includes("=")) {
                            let parts = rawCmd.split("=");
                            let varName = parts[0].trim();
                            let varValue = parseFloat(parts[1]);
                            if (!varName.includes(":")) varName = "K:" + varName;
                            
                            SimVar.SetSimVarValue(varName, "number", varValue);
                            console.log(`[LEGACY EXEC] ${varName} = ${varValue}`);
                        } 
                        else {
                            let varName = rawCmd;
                            if (!varName.includes(":")) varName = "K:" + varName;
                            
                            SimVar.SetSimVarValue(varName, "number", 1);
                            console.log(`[STANDARD EXEC] ${varName} = 1`);
                        }
                    }
                } catch(e) {
                    console.error("EFB Bridge JSON Parsing Error:", e);
                }
            });

            window.bridgeSocket.addEventListener("error", (error) => {
                if(this.statusDiv) this.statusDiv.innerHTML = "<strong style='color: red;'>NETWORK ERROR</strong>";
            });

            window.bridgeSocket.addEventListener("close", (event) => {
                if(this.statusDiv) this.statusDiv.innerHTML = `<strong style='color: red;'>DISCONNECTED</strong>`;
                if (this.telemetryInterval) clearInterval(this.telemetryInterval);
                setTimeout(() => this.initTwoWaySocket(), 5000); 
            });
        } catch (e) {
            if(this.statusDiv) this.statusDiv.innerHTML = "<strong style='color: red;'>JS ERROR: " + e.message + "</strong>";
        }
    }

    startTelemetryLoop() {
        if (this.telemetryInterval) clearInterval(this.telemetryInterval);
        
        const getVar = (name, unit, previousValue) => {
            try {
                let val = SimVar.GetSimVarValue(name, unit);
                
                if (val === undefined || val === null) {
                    return previousValue !== undefined ? previousValue : 0;
                }
                
                if (typeof val === 'number') {
                    return Math.round(val * 100) / 100;
                }
                return val;
            } catch(e) { return previousValue !== undefined ? previousValue : 0; }
        };

        this.telemetryInterval = setInterval(() => {
            try {
                if (typeof SimVar === "undefined") return;

                this.tickCount++;
                if (this.tickCount >= 50) {
                    this.previousPayload = {};
                    this.tickCount = 0;
                }

                let currentPayload = {
                    altitude: getVar("INDICATED ALTITUDE", "feet", this.previousPayload.altitude),
                    airspeed: getVar("AIRSPEED INDICATED", "knots", this.previousPayload.airspeed),
                    rpm: getVar("GENERAL ENG RPM:1", "rpm", this.previousPayload.rpm),
                    flaps_pct: getVar("FLAPS HANDLE PERCENT", "percent", this.previousPayload.flaps_pct),
                    fuel_pct: getVar("FUEL TOTAL QUANTITY", "gallons", this.previousPayload.fuel_pct),
                    ap_hdg: getVar("AUTOPILOT HEADING LOCK DIR", "degrees", this.previousPayload.ap_hdg),
                    ap_alt: getVar("AUTOPILOT ALTITUDE LOCK VAR", "feet", this.previousPayload.ap_alt),
                    ap_vs: getVar("AUTOPILOT VERTICAL HOLD VAR", "feet per minute", this.previousPayload.ap_vs),
                    ap_spd: getVar("AUTOPILOT AIRSPEED HOLD VAR", "knots", this.previousPayload.ap_spd),
                    baro: getVar("KOHLSMAN SETTING MB", "millibars", this.previousPayload.baro),
                    vs: getVar("VERTICAL SPEED", "feet per minute", this.previousPayload.vs),
                    oat: getVar("AMBIENT TEMPERATURE", "celsius", this.previousPayload.oat),
                    com1_act: getVar("COM ACTIVE FREQUENCY:1", "MHz", this.previousPayload.com1_act),
                    com1_stby: getVar("COM STANDBY FREQUENCY:1", "MHz", this.previousPayload.com1_stby),
                    nav1_act: getVar("NAV ACTIVE FREQUENCY:1", "MHz", this.previousPayload.nav1_act),
                    nav1_stby: getVar("NAV STANDBY FREQUENCY:1", "MHz", this.previousPayload.nav1_stby),
                    com2_act: getVar("COM ACTIVE FREQUENCY:2", "MHz", this.previousPayload.com2_act),
                    com2_stby: getVar("COM STANDBY FREQUENCY:2", "MHz", this.previousPayload.com2_stby),
                    nav2_act: getVar("NAV ACTIVE FREQUENCY:2", "MHz", this.previousPayload.nav2_act),
                    nav2_stby: getVar("NAV STANDBY FREQUENCY:2", "MHz", this.previousPayload.nav2_stby),
                    nav1_obs: getVar("NAV OBS:1", "degrees", this.previousPayload.nav1_obs),
                    nav2_obs: getVar("NAV OBS:2", "degrees", this.previousPayload.nav2_obs),
                    trim_elev: getVar("ELEVATOR TRIM PCT", "percent", this.previousPayload.trim_elev),
                    trim_rudder: getVar("RUDDER TRIM PCT", "percent", this.previousPayload.trim_rudder),
                    parking_brake_state: getVar("BRAKE PARKING INDICATOR", "number", this.previousPayload.parking_brake_state),
                    gear_state: getVar("GEAR HANDLE POSITION", "number", this.previousPayload.gear_state),
                    nav_light_state: getVar("LIGHT NAV ON", "number", this.previousPayload.nav_light_state),
                    beacon_state: getVar("LIGHT BEACON ON", "number", this.previousPayload.beacon_state),
                    strobe_state: getVar("LIGHT STROBE ON", "number", this.previousPayload.strobe_state),
                    taxi_state: getVar("LIGHT TAXI ON", "number", this.previousPayload.taxi_state),
                    landing_state: getVar("LIGHT LANDING ON", "number", this.previousPayload.landing_state),
                    pitot_state: getVar("PITOT HEAT", "number", this.previousPayload.pitot_state),
                    batt_state: getVar("ELECTRICAL MASTER BATTERY:1", "number", this.previousPayload.batt_state),
                    alt_state: getVar("GENERAL ENG MASTER ALTERNATOR:1", "number", this.previousPayload.alt_state),
                    ap_master_state: getVar("AUTOPILOT MASTER", "number", this.previousPayload.ap_master_state),
                    fd_state: getVar("AUTOPILOT FLIGHT DIRECTOR ACTIVE", "number", this.previousPayload.fd_state),
                    ap_hdg_state: getVar("AUTOPILOT HEADING LOCK", "number", this.previousPayload.ap_hdg_state),
                    ap_alt_state: getVar("AUTOPILOT ALTITUDE LOCK", "number", this.previousPayload.ap_alt_state),
                    ap_vs_state: getVar("AUTOPILOT VERTICAL HOLD", "number", this.previousPayload.ap_vs_state),
                    ap_nav_state: getVar("AUTOPILOT NAV1 LOCK", "number", this.previousPayload.ap_nav_state),
                    ap_apr_state: getVar("AUTOPILOT APPROACH HOLD", "number", this.previousPayload.ap_apr_state),
                    ap_athr_state: getVar("AUTOTHROTTLE ACTIVE", "number", this.previousPayload.ap_athr_state),
                    ap_flc_state: getVar("AUTOPILOT FLIGHT LEVEL CHANGE", "number", this.previousPayload.ap_flc_state),
                    ap_yd_state: getVar("AUTOPILOT YAW DAMPER", "number", this.previousPayload.ap_yd_state),
                    spoilers_arm_state: getVar("SPOILERS ARMED", "number", this.previousPayload.spoilers_arm_state),
                    eng1_starter_state: getVar("GENERAL ENG STARTER:1", "number", this.previousPayload.eng1_starter_state),
                    eng2_starter_state: getVar("GENERAL ENG STARTER:2", "number", this.previousPayload.eng2_starter_state),
                    eng1_pump_state: getVar("GENERAL ENG FUEL PUMP ON:1", "number", this.previousPayload.eng1_pump_state),
                    
                    avionics_state: getVar("AVIONICS MASTER SWITCH", "number", this.previousPayload.avionics_state),
                    alt_1_state: getVar("GENERAL ENG ALTERNATOR SWITCH:1", "number", this.previousPayload.alt_1_state),
                    fuel_pump_gen_state: getVar("GENERAL ENG FUEL PUMP SWITCH:1", "number", this.previousPayload.fuel_pump_gen_state),
                    carb_heat_state: getVar("ENG ANTI ICE:1", "number", this.previousPayload.carb_heat_state),
                    magneto_state: getVar("RECIP ENG IGNITION SWITCH:1", "number", this.previousPayload.magneto_state)
                };

                this.customVarsManifest.forEach(v => {
                    let key = "custom_" + v.name;
                    currentPayload[key] = getVar(v.name, v.unit, this.previousPayload[key]);
                });
                
                let deltaPayload = {};
                let hasChanges = false;

                for (let key in currentPayload) {
                    if (currentPayload[key] !== this.previousPayload[key]) {
                        deltaPayload[key] = currentPayload[key];
                        this.previousPayload[key] = currentPayload[key]; 
                        hasChanges = true;
                    }
                }

                if(this.telemetryDiv) {
                    this.telemetryDiv.innerHTML = `ID: ${this.pairingPin} | Alt: ${currentPayload.altitude.toFixed(0)}`;
                }

                if (hasChanges && window.bridgeSocket && window.bridgeSocket.readyState === WebSocket.OPEN) {
                    window.bridgeSocket.send(JSON.stringify(deltaPayload));
                }
            } catch (e) {}
        }, 100); 
    }
}

window.customElements.define("touch-bridge-panel", TouchBridgePanel);